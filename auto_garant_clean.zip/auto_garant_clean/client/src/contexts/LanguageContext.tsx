import { createContext, useContext, useState, type ReactNode } from "react";

export type Language = "ru" | "en" | "ka";

interface Translations {
  [key: string]: {
    ru: string;
    en: string;
    ka: string;
  };
}

const translations: Translations = {
  // Nav
  "nav.home": { ru: "Главная", en: "Home", ka: "მთავარი" },
  "nav.conditions": { ru: "Условия", en: "Terms", ka: "პირობები" },
  "nav.calculator": { ru: "Калькулятор", en: "Calculator", ka: "კალკულატორი" },
  "nav.howItWorks": { ru: "Как это работает", en: "How It Works", ka: "როგორ მუშაობს" },
  "nav.contact": { ru: "Контакты", en: "Contact", ka: "კონტაქტი" },

  // Hero
  "hero.title": {
    ru: "Авто в рассрочку",
    en: "Car Installments",
    ka: "ავტომობილი განვადებით",
  },
  "hero.subtitle": {
    ru: "без банков, без стресса",
    en: "no banks, no stress",
    ka: "ბანკების გარეშე, სტრესის გარეშე",
  },
  "hero.description": {
    ru: "Мы поможем тебе взять авто в рассрочку / лизинг, без банков, без лишних слов и стресса.",
    en: "We'll help you get a car on installments / leasing, without banks, without unnecessary words and stress.",
    ka: "ჩვენ დაგეხმარებით ავტომობილის განვადებით / ლიზინგით აღებაში, ბანკების გარეშე, ზედმეტი სიტყვებისა და სტრესის გარეშე.",
  },
  "hero.cta": {
    ru: "Рассчитать платёж",
    en: "Calculate Payment",
    ka: "გადახდის გამოთვლა",
  },
  "hero.ctaContact": {
    ru: "Связаться с нами",
    en: "Contact Us",
    ka: "დაგვიკავშირდით",
  },

  // Stats
  "stats.rate": { ru: "ежемесячно", en: "monthly", ka: "ყოველთვიურად" },
  "stats.downPayment": { ru: "первый взнос", en: "down payment", ka: "პირველი შენატანი" },
  "stats.term": { ru: "месяцев", en: "months", ka: "თვე" },

  // Conditions
  "conditions.title": { ru: "Условия", en: "Terms", ka: "პირობები" },
  "conditions.subtitle": {
    ru: "Простые и понятные условия рассрочки",
    en: "Simple and clear installment terms",
    ka: "მარტივი და გასაგები განვადების პირობები",
  },
  "conditions.downPayment.title": {
    ru: "Первоначальный взнос",
    en: "Down Payment",
    ka: "პირველი შენატანი",
  },
  "conditions.downPayment.desc": {
    ru: "от 30% стоимости автомобиля",
    en: "from 30% of the car value",
    ka: "ავტომობილის ღირებულების 30%-დან",
  },
  "conditions.monthly.title": {
    ru: "Ежемесячные платежи",
    en: "Monthly Payments",
    ka: "ყოველთვიური გადახდები",
  },
  "conditions.monthly.desc": {
    ru: "удобные платежи по 4% в месяц",
    en: "convenient payments at 4% per month",
    ka: "მოსახერხებელი გადახდები თვეში 4%",
  },
  "conditions.notary.title": {
    ru: "Нотариальное оформление",
    en: "Notary Registration",
    ka: "სანოტარო გაფორმება",
  },
  "conditions.notary.desc": {
    ru: "быстрое и официальное оформление",
    en: "fast and official registration",
    ka: "სწრაფი და ოფიციალური გაფორმება",
  },
  "conditions.honest.title": {
    ru: "Честные условия",
    en: "Fair Terms",
    ka: "სამართლიანი პირობები",
  },
  "conditions.honest.desc": {
    ru: "без скрытых комиссий и переплат",
    en: "no hidden fees or overpayments",
    ka: "ფარული საკომისიოებისა და ზედმეტი გადახდების გარეშე",
  },

  // Who is it for
  "whoFor.title": { ru: "Для кого подходит", en: "Who Is It For", ka: "ვისთვისაა" },
  "whoFor.noMoney": {
    ru: "Нет всей суммы сразу",
    en: "Don't have the full amount",
    ka: "არ გაქვთ სრული თანხა",
  },
  "whoFor.bankRefused": {
    ru: "Банк отказал в кредите",
    en: "Bank refused a loan",
    ka: "ბანკმა სესხზე უარი თქვა",
  },
  "whoFor.changeCar": {
    ru: "Хочешь сменить авто без кредита",
    en: "Want to change car without a loan",
    ka: "გინდა მანქანის შეცვლა სესხის გარეშე",
  },

  // Calculator
  "calc.title": { ru: "Калькулятор", en: "Calculator", ka: "კალკულატორი" },
  "calc.subtitle": {
    ru: "Рассчитайте ваш ежемесячный платёж",
    en: "Calculate your monthly payment",
    ka: "გამოთვალეთ თქვენი ყოველთვიური გადახდა",
  },
  "calc.carPrice": { ru: "Стоимость авто", en: "Car Price", ka: "ავტომობილის ფასი" },
  "calc.downPaymentPercent": { ru: "Первый взнос", en: "Down Payment", ka: "პირველი შენატანი" },
  "calc.term": { ru: "Срок (месяцев)", en: "Term (months)", ka: "ვადა (თვეები)" },
  "calc.monthlyPayment": { ru: "Ежемесячный платёж", en: "Monthly Payment", ka: "ყოველთვიური გადახდა" },
  "calc.downPaymentAmount": { ru: "Первоначальный взнос", en: "Down Payment Amount", ka: "პირველი შენატანის თანხა" },
  "calc.totalAmount": { ru: "Общая сумма выплат", en: "Total Payment Amount", ka: "გადახდის ჯამური თანხა" },
  "calc.loanAmount": { ru: "Сумма рассрочки", en: "Installment Amount", ka: "განვადების თანხა" },
  "calc.contactUs": {
    ru: "Оформить рассрочку",
    en: "Apply for Installment",
    ka: "განვადების გაფორმება",
  },

  // How it works
  "how.title": { ru: "Как это работает", en: "How It Works", ka: "როგორ მუშაობს" },
  "how.step1.title": { ru: "Выбери авто", en: "Choose a Car", ka: "აირჩიე ავტომობილი" },
  "how.step1.desc": {
    ru: "Ты выбираешь автомобиль, который тебе нравится",
    en: "You choose the car you like",
    ka: "აირჩიე ავტომობილი, რომელიც მოგწონს",
  },
  "how.step2.title": { ru: "Свяжись с нами", en: "Contact Us", ka: "დაგვიკავშირდი" },
  "how.step2.desc": {
    ru: "Обсуждаем условия и согласовываем детали",
    en: "We discuss terms and agree on details",
    ka: "განვიხილავთ პირობებს და შევთანხმდებით დეტალებზე",
  },
  "how.step3.title": { ru: "Оформление", en: "Registration", ka: "გაფორმება" },
  "how.step3.desc": {
    ru: "Быстрое нотариальное оформление документов",
    en: "Fast notary registration of documents",
    ka: "დოკუმენტების სწრაფი სანოტარო გაფორმება",
  },
  "how.step4.title": { ru: "За рулём!", en: "Behind the Wheel!", ka: "საჭესთან!" },
  "how.step4.desc": {
    ru: "Ты уже за рулём своего нового авто",
    en: "You're already behind the wheel of your new car",
    ka: "უკვე შენი ახალი ავტომობილის საჭესთან ხარ",
  },

  // Contact
  "contact.title": { ru: "Связаться с нами", en: "Contact Us", ka: "დაგვიკავშირდით" },
  "contact.subtitle": {
    ru: "Выберите удобный способ связи",
    en: "Choose a convenient way to contact us",
    ka: "აირჩიეთ კომუნიკაციის მოსახერხებელი საშუალება",
  },
  "contact.telegram": { ru: "Написать в Telegram", en: "Write on Telegram", ka: "Telegram-ში მოწერა" },
  "contact.whatsapp": { ru: "Написать в WhatsApp", en: "Write on WhatsApp", ka: "WhatsApp-ში მოწერა" },
  "contact.call": { ru: "Позвонить", en: "Call Us", ka: "დარეკვა" },

  // Footer
  "footer.rights": {
    ru: "Все права защищены",
    en: "All rights reserved",
    ka: "ყველა უფლება დაცულია",
  },
  "footer.disclaimer": {
    ru: "Рассрочка предоставляется от частного лица. Не является банковским продуктом.",
    en: "Installments provided by a private person. Not a banking product.",
    ka: "განვადებას გასცემს კერძო პირი. არ არის საბანკო პროდუქტი.",
  },

  // Currency
  "currency": { ru: "$", en: "$", ka: "$" },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("ru");

  const t = (key: string): string => {
    const translation = translations[key];
    if (!translation) return key;
    return translation[language] || translation.ru || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used within LanguageProvider");
  return context;
}
