/*
 * Design: Dark Premium Automotive
 * Home: Single page assembling all sections
 * Montserrat headings, Roboto body, gold (#D4A853) accents on dark (#0D0D0D) bg
 */
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import ConditionsSection from "@/components/ConditionsSection";
import CalculatorSection from "@/components/CalculatorSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import ContactSection from "@/components/ContactSection";
import FloatingButtons from "@/components/FloatingButtons";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <ConditionsSection />
      <CalculatorSection />
      <HowItWorksSection />
      <ContactSection />
      <Footer />
      <FloatingButtons />
    </div>
  );
}
