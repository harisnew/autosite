/*
 * Design: Dark Premium Automotive
 * Hero: Full-screen with car image, large typography, gold accents
 * Mobile: Smaller text, stacked buttons, compact stats
 */
import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";

const HERO_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663152654847/mH7NeeYkz6JRMpGvmXxyKo/hero-car-VpxwkZsJocrf8jgnskrbfy.webp";

export default function HeroSection() {
  const { t } = useLanguage();

  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="home" className="relative min-h-[100svh] flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={HERO_IMAGE}
          alt="Luxury car"
          className="w-full h-full object-cover object-center"
          loading="eager"
        />
        {/* Overlay gradients — stronger on mobile for text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.08_0.005_250_/_95%)] via-[oklch(0.10_0.005_250_/_80%)] to-[oklch(0.08_0.005_250_/_50%)] sm:from-[oklch(0.08_0.005_250_/_92%)] sm:via-[oklch(0.10_0.005_250_/_75%)] sm:to-[oklch(0.08_0.005_250_/_60%)]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.13_0.005_250)] via-transparent to-[oklch(0.13_0.005_250_/_40%)]" />
      </div>

      {/* Content */}
      <div className="container relative z-10 pt-20 sm:pt-24 pb-12 sm:pb-16">
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 rounded-full border border-gold/30 bg-gold/5 mb-5 sm:mb-8">
              <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-gold animate-pulse" />
              <span className="text-gold text-xs sm:text-sm font-medium tracking-wide" style={{ fontFamily: "var(--font-heading)" }}>
                AUTO GARANT
              </span>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold leading-[1.1] mb-3 sm:mb-4"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            <span className="text-foreground">{t("hero.title")}</span>
            <br />
            <span className="gold-gradient">{t("hero.subtitle")}</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-base sm:text-lg md:text-xl text-muted-foreground mb-7 sm:mb-10 max-w-lg leading-relaxed"
          >
            {t("hero.description")}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="flex flex-col sm:flex-row gap-3 sm:gap-4"
          >
            <button
              onClick={() => scrollTo("#calculator")}
              className="px-6 py-3.5 sm:px-8 sm:py-4 bg-gold text-[#0D0D0D] font-bold text-sm sm:text-base rounded-lg hover:bg-gold-light transition-all duration-300 hover:shadow-lg hover:shadow-gold/20 active:scale-95"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              {t("hero.cta")}
            </button>
            <button
              onClick={() => scrollTo("#contact")}
              className="px-6 py-3.5 sm:px-8 sm:py-4 border border-gold/40 text-gold font-bold text-sm sm:text-base rounded-lg hover:bg-gold/10 transition-all duration-300 active:scale-95"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              {t("hero.ctaContact")}
            </button>
          </motion.div>

          {/* Stats Row */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.0 }}
            className="flex gap-6 sm:gap-8 md:gap-12 mt-10 sm:mt-14 pt-6 sm:pt-8 border-t border-border/50"
          >
            <div>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-gold" style={{ fontFamily: "var(--font-heading)" }}>4%</div>
              <div className="text-xs sm:text-sm text-muted-foreground mt-0.5 sm:mt-1">{t("stats.rate")}</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-gold" style={{ fontFamily: "var(--font-heading)" }}>30%</div>
              <div className="text-xs sm:text-sm text-muted-foreground mt-0.5 sm:mt-1">{t("stats.downPayment")}</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-gold" style={{ fontFamily: "var(--font-heading)" }}>1–18</div>
              <div className="text-xs sm:text-sm text-muted-foreground mt-0.5 sm:mt-1">{t("stats.term")}</div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator — hidden on very small screens */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 z-10 hidden sm:block"
      >
        <button
          onClick={() => scrollTo("#conditions")}
          className="flex flex-col items-center gap-2 text-muted-foreground hover:text-gold transition-colors"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            <ChevronDown size={24} />
          </motion.div>
        </button>
      </motion.div>
    </section>
  );
}
