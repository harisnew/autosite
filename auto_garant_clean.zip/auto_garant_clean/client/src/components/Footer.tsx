/*
 * Design: Dark Premium Automotive
 * Footer: Minimal, gold accent line, copyright + disclaimer
 * Mobile: Stacked layout, smaller text
 */
import { useLanguage } from "@/contexts/LanguageContext";

export default function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="relative py-8 sm:py-10 border-t border-border/30">
      <div className="gold-line w-full absolute top-0" />
      <div className="container">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-base sm:text-lg tracking-tight" style={{ fontFamily: "var(--font-heading)" }}>
              <span className="text-gold">AUTO</span>
              <span className="text-foreground"> GARANT</span>
            </span>
          </div>
          <div className="text-center sm:text-right">
            <p className="text-xs sm:text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} Auto Garant. {t("footer.rights")}
            </p>
            <p className="text-[10px] sm:text-xs text-muted-foreground/60 mt-0.5 sm:mt-1 max-w-xs sm:max-w-none">
              {t("footer.disclaimer")}
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
