/*
 * Design: Dark Premium Automotive
 * Contact: Large CTA buttons for Telegram, WhatsApp, Phone
 * Mobile: Full-width buttons, compact padding, touch-friendly
 */
import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { Phone, MessageCircle, Send } from "lucide-react";

const CAR_INTERIOR_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663152654847/mH7NeeYkz6JRMpGvmXxyKo/car-interior-9XWD8aC8UEpYkhoxPoAMyJ.webp";

const PHONE_NUMBER = "+995555486034";
const PHONE_DISPLAY = "+995 555 486 034";
const TELEGRAM_LINK = "https://t.me/auto_garant_ge";
const WHATSAPP_LINK = `https://wa.me/${PHONE_NUMBER.replace(/\+/g, "")}`;

export default function ContactSection() {
  const { t } = useLanguage();

  const contacts = [
    {
      icon: Send,
      label: t("contact.telegram"),
      href: TELEGRAM_LINK,
      sublabel: "@auto_garant_ge",
      color: "from-[#2AABEE] to-[#229ED9]",
      hoverBg: "hover:bg-[#2AABEE]/10",
    },
    {
      icon: MessageCircle,
      label: t("contact.whatsapp"),
      href: WHATSAPP_LINK,
      sublabel: PHONE_DISPLAY,
      color: "from-[#25D366] to-[#128C7E]",
      hoverBg: "hover:bg-[#25D366]/10",
    },
    {
      icon: Phone,
      label: t("contact.call"),
      href: `tel:${PHONE_NUMBER}`,
      sublabel: PHONE_DISPLAY,
      color: "from-gold to-gold-dark",
      hoverBg: "hover:bg-gold/10",
    },
  ];

  return (
    <section id="contact" className="relative py-16 sm:py-24 lg:py-32 overflow-hidden">
      <div className="gold-line w-full mb-0" />

      {/* Background */}
      <div className="absolute inset-0 opacity-[0.06]">
        <img
          src={CAR_INTERIOR_IMAGE}
          alt=""
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/97 to-background" />

      <div className="container relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="text-center mb-10 sm:mb-16"
        >
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            <span className="gold-gradient">{t("contact.title")}</span>
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-md mx-auto">
            {t("contact.subtitle")}
          </p>
        </motion.div>

        {/* Contact Buttons */}
        <div className="max-w-2xl mx-auto space-y-3 sm:space-y-5">
          {contacts.map((contact, i) => (
            <motion.a
              key={i}
              href={contact.href}
              target={contact.href.startsWith("tel:") ? undefined : "_blank"}
              rel={contact.href.startsWith("tel:") ? undefined : "noopener noreferrer"}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.12 }}
              className={`glass-card rounded-xl p-4 sm:p-5 md:p-6 flex items-center gap-3 sm:gap-5 group hover:border-gold/40 transition-all duration-500 ${contact.hoverBg} block`}
            >
              <div className={`w-11 h-11 sm:w-14 sm:h-14 rounded-lg sm:rounded-xl bg-gradient-to-br ${contact.color} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                <contact.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <div
                  className="text-base sm:text-lg font-semibold text-foreground group-hover:text-gold transition-colors duration-300 truncate"
                  style={{ fontFamily: "var(--font-heading)" }}
                >
                  {contact.label}
                </div>
                <div className="text-xs sm:text-sm text-muted-foreground mt-0.5 truncate">
                  {contact.sublabel}
                </div>
              </div>
              <div className="ml-auto shrink-0">
                <svg className="w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground group-hover:text-gold group-hover:translate-x-1 transition-all duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
