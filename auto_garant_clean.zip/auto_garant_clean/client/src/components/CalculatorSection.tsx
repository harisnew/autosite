/*
 * Design: Dark Premium Automotive
 * Calculator: Glass card with gold sliders, live-updating numbers
 * Mobile: Stacked layout, larger touch targets for sliders, compact results
 */
import { useState, useMemo } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { Calculator, DollarSign, TrendingUp, CreditCard } from "lucide-react";

export default function CalculatorSection() {
  const { t } = useLanguage();
  const [carPrice, setCarPrice] = useState(15000);
  const [downPaymentPercent, setDownPaymentPercent] = useState(30);
  const [term, setTerm] = useState(12);

  const calculation = useMemo(() => {
    const downPaymentAmount = (carPrice * downPaymentPercent) / 100;
    const loanAmount = carPrice - downPaymentAmount;
    const monthlyInterest = loanAmount * 0.04;
    const monthlyPrincipal = loanAmount / term;
    const monthlyPayment = monthlyPrincipal + monthlyInterest;
    const totalPayment = downPaymentAmount + monthlyPayment * term;

    return {
      downPaymentAmount,
      loanAmount,
      monthlyPayment,
      totalPayment,
    };
  }, [carPrice, downPaymentPercent, term]);

  const formatMoney = (val: number) => {
    return val.toLocaleString("en-US", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
  };

  const getSliderBg = (value: number, min: number, max: number) => {
    const pct = ((value - min) / (max - min)) * 100;
    return `linear-gradient(to right, oklch(0.78 0.12 85) 0%, oklch(0.78 0.12 85) ${pct}%, oklch(0.22 0.008 250) ${pct}%, oklch(0.22 0.008 250) 100%)`;
  };

  return (
    <section id="calculator" className="relative py-16 sm:py-24 lg:py-32">
      <div className="gold-line w-full mb-0" />

      <div className="container">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="text-center mb-10 sm:mb-16"
        >
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            <span className="gold-gradient">{t("calc.title")}</span>
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-md mx-auto">
            {t("calc.subtitle")}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <div className="glass-card rounded-2xl p-5 sm:p-6 md:p-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10">
              {/* Left: Sliders */}
              <div className="space-y-6 sm:space-y-8">
                {/* Car Price */}
                <div>
                  <div className="flex justify-between items-center mb-2 sm:mb-3">
                    <label className="text-xs sm:text-sm font-medium text-muted-foreground uppercase tracking-wide" style={{ fontFamily: "var(--font-heading)" }}>
                      {t("calc.carPrice")}
                    </label>
                    <span className="text-lg sm:text-xl font-bold text-gold" style={{ fontFamily: "var(--font-heading)" }}>
                      ${formatMoney(carPrice)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={3000}
                    max={100000}
                    step={500}
                    value={carPrice}
                    onChange={(e) => setCarPrice(Number(e.target.value))}
                    className="w-full h-2 sm:h-2 rounded-full appearance-none cursor-pointer touch-none"
                    style={{ background: getSliderBg(carPrice, 3000, 100000) }}
                  />
                  <div className="flex justify-between text-[10px] sm:text-xs text-muted-foreground mt-1">
                    <span>$3,000</span>
                    <span>$100,000</span>
                  </div>
                </div>

                {/* Down Payment */}
                <div>
                  <div className="flex justify-between items-center mb-2 sm:mb-3">
                    <label className="text-xs sm:text-sm font-medium text-muted-foreground uppercase tracking-wide" style={{ fontFamily: "var(--font-heading)" }}>
                      {t("calc.downPaymentPercent")}
                    </label>
                    <span className="text-lg sm:text-xl font-bold text-gold" style={{ fontFamily: "var(--font-heading)" }}>
                      {downPaymentPercent}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={30}
                    max={90}
                    step={5}
                    value={downPaymentPercent}
                    onChange={(e) => setDownPaymentPercent(Number(e.target.value))}
                    className="w-full h-2 sm:h-2 rounded-full appearance-none cursor-pointer touch-none"
                    style={{ background: getSliderBg(downPaymentPercent, 30, 90) }}
                  />
                  <div className="flex justify-between text-[10px] sm:text-xs text-muted-foreground mt-1">
                    <span>30%</span>
                    <span>90%</span>
                  </div>
                </div>

                {/* Term */}
                <div>
                  <div className="flex justify-between items-center mb-2 sm:mb-3">
                    <label className="text-xs sm:text-sm font-medium text-muted-foreground uppercase tracking-wide" style={{ fontFamily: "var(--font-heading)" }}>
                      {t("calc.term")}
                    </label>
                    <span className="text-lg sm:text-xl font-bold text-gold" style={{ fontFamily: "var(--font-heading)" }}>
                      {term}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={18}
                    step={1}
                    value={term}
                    onChange={(e) => setTerm(Number(e.target.value))}
                    className="w-full h-2 sm:h-2 rounded-full appearance-none cursor-pointer touch-none"
                    style={{ background: getSliderBg(term, 1, 18) }}
                  />
                  <div className="flex justify-between text-[10px] sm:text-xs text-muted-foreground mt-1">
                    <span>1</span>
                    <span>18</span>
                  </div>
                </div>
              </div>

              {/* Right: Results */}
              <div className="space-y-4 sm:space-y-5">
                {/* Monthly Payment - Highlighted */}
                <div className="bg-gold/10 border border-gold/30 rounded-xl p-4 sm:p-6">
                  <div className="flex items-center gap-2 sm:gap-3 mb-1.5 sm:mb-2">
                    <CreditCard className="w-4 h-4 sm:w-5 sm:h-5 text-gold" />
                    <span className="text-xs sm:text-sm font-medium text-gold uppercase tracking-wide" style={{ fontFamily: "var(--font-heading)" }}>
                      {t("calc.monthlyPayment")}
                    </span>
                  </div>
                  <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-gold" style={{ fontFamily: "var(--font-heading)" }}>
                    ${formatMoney(calculation.monthlyPayment)}
                  </div>
                </div>

                {/* Other results */}
                <div className="grid grid-cols-1 gap-3 sm:gap-4">
                  <div className="flex items-center justify-between p-3 sm:p-4 rounded-xl bg-secondary/30 border border-border/50">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <DollarSign className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground shrink-0" />
                      <span className="text-xs sm:text-sm text-muted-foreground">{t("calc.downPaymentAmount")}</span>
                    </div>
                    <span className="text-base sm:text-lg font-semibold text-foreground ml-2" style={{ fontFamily: "var(--font-heading)" }}>
                      ${formatMoney(calculation.downPaymentAmount)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 sm:p-4 rounded-xl bg-secondary/30 border border-border/50">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <Calculator className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground shrink-0" />
                      <span className="text-xs sm:text-sm text-muted-foreground">{t("calc.loanAmount")}</span>
                    </div>
                    <span className="text-base sm:text-lg font-semibold text-foreground ml-2" style={{ fontFamily: "var(--font-heading)" }}>
                      ${formatMoney(calculation.loanAmount)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 sm:p-4 rounded-xl bg-secondary/30 border border-border/50">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground shrink-0" />
                      <span className="text-xs sm:text-sm text-muted-foreground">{t("calc.totalAmount")}</span>
                    </div>
                    <span className="text-base sm:text-lg font-semibold text-foreground ml-2" style={{ fontFamily: "var(--font-heading)" }}>
                      ${formatMoney(calculation.totalPayment)}
                    </span>
                  </div>
                </div>

                {/* CTA Button */}
                <a
                  href="https://t.me/auto_garant_ge"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full text-center px-6 py-3.5 sm:px-8 sm:py-4 bg-gold text-[#0D0D0D] font-bold text-sm sm:text-base rounded-lg hover:bg-gold-light transition-all duration-300 hover:shadow-lg hover:shadow-gold/20 active:scale-95 mt-2 sm:mt-4"
                  style={{ fontFamily: "var(--font-heading)" }}
                >
                  {t("calc.contactUs")}
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
