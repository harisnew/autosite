/*
 * Design: Dark Premium Automotive
 * Floating quick-action buttons: Telegram, WhatsApp, Phone
 * Mobile: Slightly smaller, safe area aware positioning
 */
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, MessageCircle, Send, X, MessageSquare } from "lucide-react";

const PHONE_NUMBER = "+995555486034";
const TELEGRAM_LINK = "https://t.me/auto_garant_ge";
const WHATSAPP_LINK = `https://wa.me/${PHONE_NUMBER.replace(/\+/g, "")}`;

export default function FloatingButtons() {
  const [open, setOpen] = useState(false);

  const buttons = [
    {
      icon: Send,
      href: TELEGRAM_LINK,
      label: "Telegram",
      bg: "bg-[#2AABEE]",
    },
    {
      icon: MessageCircle,
      href: WHATSAPP_LINK,
      label: "WhatsApp",
      bg: "bg-[#25D366]",
    },
    {
      icon: Phone,
      href: `tel:${PHONE_NUMBER}`,
      label: "Phone",
      bg: "bg-gold",
    },
  ];

  return (
    <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 flex flex-col items-end gap-2.5 sm:gap-3">
      <AnimatePresence>
        {open &&
          buttons.map((btn, i) => (
            <motion.a
              key={btn.label}
              href={btn.href}
              target={btn.href.startsWith("tel:") ? undefined : "_blank"}
              rel={btn.href.startsWith("tel:") ? undefined : "noopener noreferrer"}
              initial={{ opacity: 0, scale: 0.5, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.5, y: 20 }}
              transition={{ duration: 0.2, delay: i * 0.08 }}
              className={`${btn.bg} w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center shadow-lg hover:scale-110 active:scale-95 transition-transform duration-200`}
              title={btn.label}
            >
              <btn.icon className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-white" />
            </motion.a>
          ))}
      </AnimatePresence>

      <motion.button
        onClick={() => setOpen(!open)}
        className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gold text-[#0D0D0D] flex items-center justify-center shadow-xl shadow-gold/20 hover:bg-gold-light active:scale-90 transition-all duration-300"
        whileTap={{ scale: 0.9 }}
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <X className="w-5 h-5 sm:w-6 sm:h-6" />
            </motion.div>
          ) : (
            <motion.div
              key="open"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <MessageSquare className="w-5 h-5 sm:w-6 sm:h-6" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  );
}
