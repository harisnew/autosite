/*
 * Design: Dark Premium Automotive
 * How It Works: Steps with numbered cards, gold accents
 * Mobile: 2-column grid on small screens, single column on very small
 */
import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { Car, MessageCircle, FileText, KeyRound } from "lucide-react";

const HANDSHAKE_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663152654847/mH7NeeYkz6JRMpGvmXxyKo/handshake-deal-SxiRLVrtQgL3xuoeqgHGa3.webp";

export default function HowItWorksSection() {
  const { t } = useLanguage();

  const steps = [
    { icon: Car, title: t("how.step1.title"), desc: t("how.step1.desc"), num: "01" },
    { icon: MessageCircle, title: t("how.step2.title"), desc: t("how.step2.desc"), num: "02" },
    { icon: FileText, title: t("how.step3.title"), desc: t("how.step3.desc"), num: "03" },
    { icon: KeyRound, title: t("how.step4.title"), desc: t("how.step4.desc"), num: "04" },
  ];

  return (
    <section id="how-it-works" className="relative py-16 sm:py-24 lg:py-32 overflow-hidden">
      <div className="gold-line w-full mb-0" />

      {/* Background image with overlay */}
      <div className="absolute inset-0 opacity-10">
        <img
          src={HANDSHAKE_IMAGE}
          alt=""
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />

      <div className="container relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="text-center mb-10 sm:mb-16"
        >
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            <span className="gold-gradient">{t("how.title")}</span>
          </h2>
        </motion.div>

        {/* Steps */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-4">
          {steps.map((step, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="relative"
            >
              <div className="glass-card rounded-xl p-4 sm:p-6 text-center relative z-10 hover:border-gold/40 transition-all duration-500 group h-full">
                {/* Step number */}
                <div className="text-3xl sm:text-5xl font-black text-gold/10 absolute top-2 right-3 sm:top-3 sm:right-4" style={{ fontFamily: "var(--font-heading)" }}>
                  {step.num}
                </div>

                <div className="w-10 h-10 sm:w-14 sm:h-14 rounded-lg sm:rounded-xl bg-gold/10 flex items-center justify-center mx-auto mb-3 sm:mb-5 group-hover:bg-gold/20 transition-colors duration-300">
                  <step.icon className="w-5 h-5 sm:w-7 sm:h-7 text-gold" />
                </div>

                <h3
                  className="text-sm sm:text-lg font-bold mb-1.5 sm:mb-3 text-foreground"
                  style={{ fontFamily: "var(--font-heading)" }}
                >
                  {step.title}
                </h3>
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                  {step.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
