/*
 * Design: Dark Premium Automotive
 * Conditions: Grid of glass cards with gold icon accents
 * Mobile: Single column cards, image hidden on mobile, compact spacing
 */
import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { Percent, Calendar, FileCheck, ShieldCheck } from "lucide-react";

const CAR_KEYS_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663152654847/mH7NeeYkz6JRMpGvmXxyKo/car-keys-Zb4P7SCxHUNjpnX7L3kFxq.webp";

export default function ConditionsSection() {
  const { t } = useLanguage();

  const conditions = [
    {
      icon: Percent,
      title: t("conditions.downPayment.title"),
      desc: t("conditions.downPayment.desc"),
    },
    {
      icon: Calendar,
      title: t("conditions.monthly.title"),
      desc: t("conditions.monthly.desc"),
    },
    {
      icon: FileCheck,
      title: t("conditions.notary.title"),
      desc: t("conditions.notary.desc"),
    },
    {
      icon: ShieldCheck,
      title: t("conditions.honest.title"),
      desc: t("conditions.honest.desc"),
    },
  ];

  return (
    <section id="conditions" className="relative py-16 sm:py-24 lg:py-32 overflow-hidden">
      <div className="gold-line w-full mb-0" />

      <div className="container">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="text-center mb-10 sm:mb-16"
        >
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            <span className="gold-gradient">{t("conditions.title")}</span>
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-md mx-auto">
            {t("conditions.subtitle")}
          </p>
        </motion.div>

        {/* Two-column layout: image + cards */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Left: Image — hidden on mobile/tablet */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="relative hidden lg:block"
          >
            <div className="relative rounded-2xl overflow-hidden">
              <img
                src={CAR_KEYS_IMAGE}
                alt="Car keys"
                className="w-full h-auto object-cover rounded-2xl"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
            </div>
            <div className="absolute -inset-1 rounded-2xl border border-gold/20 -z-10" />
          </motion.div>

          {/* Right: Condition Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
            {conditions.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="glass-card rounded-xl p-5 sm:p-6 hover:border-gold/40 transition-all duration-500 group"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-gold/10 flex items-center justify-center mb-3 sm:mb-4 group-hover:bg-gold/20 transition-colors duration-300">
                  <item.icon className="w-5 h-5 sm:w-6 sm:h-6 text-gold" />
                </div>
                <h3
                  className="text-base sm:text-lg font-semibold mb-1.5 sm:mb-2 text-foreground"
                  style={{ fontFamily: "var(--font-heading)" }}
                >
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {item.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Who is it for */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-14 sm:mt-20"
        >
          <h3
            className="text-xl sm:text-2xl md:text-3xl font-bold text-center mb-6 sm:mb-10"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            {t("whoFor.title")}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
            {[
              t("whoFor.noMoney"),
              t("whoFor.bankRefused"),
              t("whoFor.changeCar"),
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="flex items-center gap-3 sm:gap-4 p-4 sm:p-5 rounded-xl border border-border/50 bg-card/50 hover:border-gold/30 transition-all duration-300"
              >
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-gold/15 flex items-center justify-center shrink-0">
                  <svg className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-sm sm:text-base text-foreground font-medium">{item}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
